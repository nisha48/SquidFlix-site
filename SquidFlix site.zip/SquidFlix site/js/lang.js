const translations = {
  en: {
    welcome: "Welcome to SquidFlix",
    movies: "Movies",
    series: "Series",
    anime: "Anime",
    trailers: "Trailers",
    login: "Login",
    signup: "Sign Up"
  },
  si: {
    welcome: "ස්කුයිඩ් ෆ්ලික්ස් වෙත ඔබව සාදරයෙන් පිළිගනිමු",
    movies: "සිනමා",
    series: "ශ්‍රේණි",
    anime: "ඇනිමේ",
    trailers: "ට්‍රේලර්",
    login: "ප්‍රවිශ්ට වෙන්න",
    signup: "ලියාපදිංචි වන්න"
  },
};

function setLanguage(lang) {
  document.querySelectorAll("[data-translate]").forEach(el => {
    const key = el.getAttribute("data-translate");
    if (translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });
}

document.getElementById("lang-select").addEventListener("change", (e) => {
  setLanguage(e.target.value);
});